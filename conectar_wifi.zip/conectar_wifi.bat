@echo off
setlocal
chcp 65001 >nul

set "SSID=wifi-Playtech-SP"
set "SENHA=xo11tzPlk4n4"
set "PERFIL=%TEMP%\wifi_perfil.xml"

echo Criando perfil da rede %SSID%...
(
echo ^<?xml version="1.0"?^>
echo ^<WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1"^>
echo   ^<name^>%SSID%^</name^>
echo   ^<SSIDConfig^>^<SSID^>^<name^>%SSID%^</name^>^</SSID^>^</SSIDConfig^>
echo   ^<connectionType^>ESS^</connectionType^>
echo   ^<connectionMode^>auto^</connectionMode^>
echo   ^<MSM^>^<security^>
echo     ^<authEncryption^>
echo       ^<authentication^>WPA2PSK^</authentication^>
echo       ^<encryption^>AES^</encryption^>
echo       ^<useOneX^>false^</useOneX^>
echo     ^</authEncryption^>
echo     ^<sharedKey^>
echo       ^<keyType^>passPhrase^</keyType^>
echo       ^<protected^>false^</protected^>
echo       ^<keyMaterial^>%SENHA%^</keyMaterial^>
echo     ^</sharedKey^>
echo   ^</security^>^</MSM^>
echo ^</WLANProfile^>
) > "%PERFIL%"

netsh wlan add profile filename="%PERFIL%" user=current
del /q "%PERFIL%"

echo Conectando...
netsh wlan connect name="%SSID%" ssid="%SSID%"

timeout /t 5 /nobreak >nul
netsh wlan show interfaces | findstr /i "SSID Estado State"

pause
endlocal
