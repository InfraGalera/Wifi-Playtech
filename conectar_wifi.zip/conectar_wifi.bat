@echo off
setlocal EnableExtensions
chcp 65001 >nul

set "SSID=wifi-Playtech-SP"
set "SENHA=xo11tzPlk4n4"
set "REDE_ANTIGA=wifi-glr"
set "PERFIL=%TEMP%\wifi_perfil.xml"
set "LOG=%TEMP%\wifi_conectar.txt"

rem Como administrador, salva a rede para todos os usuarios do notebook
set "ESCOPO=current"
net session >nul 2>&1 && set "ESCOPO=all"

echo.
echo [1/3] Salvando a rede %SSID%...
(
echo ^<?xml version="1.0"?^>
echo ^<WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1"^>
echo   ^<name^>%SSID%^</name^>
echo   ^<SSIDConfig^>^<SSID^>^<name^>%SSID%^</name^>^</SSID^>^</SSIDConfig^>
echo   ^<connectionType^>ESS^</connectionType^>
echo   ^<connectionMode^>auto^</connectionMode^>
echo   ^<MSM^>^<security^>
echo     ^<authEncryption^>
echo       ^<authentication^>WPA2PSK^</authentication^>
echo       ^<encryption^>AES^</encryption^>
echo       ^<useOneX^>false^</useOneX^>
echo     ^</authEncryption^>
echo     ^<sharedKey^>
echo       ^<keyType^>passPhrase^</keyType^>
echo       ^<protected^>false^</protected^>
echo       ^<keyMaterial^>%SENHA%^</keyMaterial^>
echo     ^</sharedKey^>
echo   ^</security^>^</MSM^>
echo ^</WLANProfile^>
) > "%PERFIL%"

netsh wlan add profile filename="%PERFIL%" user=%ESCOPO% > "%LOG%" 2>&1
if errorlevel 1 (
  del /q "%PERFIL%" >nul 2>&1
  echo ERRO: nao foi possivel salvar a rede. Detalhes:
  type "%LOG%"
  echo Verifique se o Wi-Fi do notebook esta ligado.
  goto fim
)
del /q "%PERFIL%" >nul 2>&1
echo       OK.

echo [2/3] Procurando a rede antiga %REDE_ANTIGA%...
call :tem_rede_antiga
if errorlevel 1 (
  echo       Nao encontrada neste notebook. Nada a remover.
) else (
  netsh wlan disconnect >nul 2>&1
  netsh wlan delete profile name="%REDE_ANTIGA%" >nul 2>&1
  call :tem_rede_antiga
  if errorlevel 1 (
    echo       Rede %REDE_ANTIGA% removida.
  ) else (
    echo       AVISO: o Windows nao deixou remover %REDE_ANTIGA%.
    echo       Feche esta janela, clique com o botao direito no arquivo
    echo       e escolha "Executar como administrador".
  )
)

echo [3/3] Conectando a %SSID%...
set /a TENTATIVA=0
:loop
set /a RESTO=TENTATIVA %% 5
if %RESTO%==0 netsh wlan connect name="%SSID%" ssid="%SSID%" > "%LOG%" 2>&1
timeout /t 2 /nobreak >nul
call :conectado && goto sucesso
set /a TENTATIVA+=1
if %TENTATIVA% lss 15 goto loop

echo.
echo Nao foi possivel conectar a %SSID% automaticamente.
type "%LOG%"
findstr /i "location localiza" "%LOG%" >nul && (
  echo.
  echo O Windows esta pedindo a permissao de Localizacao.
  echo Vou abrir a tela de Localizacao: ative-a e rode este arquivo de novo.
  start "" ms-settings:privacy-location
  goto fim
)
echo.
echo A rede ja esta salva. Clique no icone de Wi-Fi perto do relogio
echo e escolha %SSID%. Verifique tambem se o Wi-Fi esta ligado.
goto fim

:sucesso
echo.
echo Pronto! Conectado a %SSID%.
goto fim

rem ---------- funcoes ----------
:tem_rede_antiga
netsh wlan show profiles | findstr /r /i /c:": %REDE_ANTIGA% *$" >nul
exit /b %errorlevel%

:conectado
powershell -NoProfile -Command "if (@(Get-NetConnectionProfile -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '%SSID%*' }).Count) { exit 0 } else { exit 1 }" >nul 2>&1
exit /b %errorlevel%

:fim
del /q "%LOG%" >nul 2>&1
echo.
pause
endlocal
