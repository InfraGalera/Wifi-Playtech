@echo off
setlocal
chcp 65001 >nul

set "SSID=wifi-Playtech-SP"
set "SENHA=xo11tzPlk4n4"
set "REDE_ANTIGA=wifi-glr"
set "PERFIL=%TEMP%\wifi_perfil.xml"

echo Criando perfil da rede %SSID%...
(
echo ^<?xml version="1.0"?^>
echo ^<WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1"^>
echo   ^<name^>%SSID%^</name^>
echo   ^<SSIDConfig^>^<SSID^>^<name^>%SSID%^</name^>^</SSID^>^</SSIDConfig^>
echo   ^<connectionType^>ESS^</connectionType^>
echo   ^<connectionMode^>auto^</connectionMode^>
echo   ^<MSM^>^<security^>
echo     ^<authEncryption^>
echo       ^<authentication^>WPA2PSK^</authentication^>
echo       ^<encryption^>AES^</encryption^>
echo       ^<useOneX^>false^</useOneX^>
echo     ^</authEncryption^>
echo     ^<sharedKey^>
echo       ^<keyType^>passPhrase^</keyType^>
echo       ^<protected^>false^</protected^>
echo       ^<keyMaterial^>%SENHA%^</keyMaterial^>
echo     ^</sharedKey^>
echo   ^</security^>^</MSM^>
echo ^</WLANProfile^>
) > "%PERFIL%"

netsh wlan add profile filename="%PERFIL%" user=current >nul
del /q "%PERFIL%"

echo Conectando a %SSID%...
netsh wlan connect name="%SSID%" ssid="%SSID%" >nul

rem Aguarda ate 20 segundos a conexao com a nova rede
set /a TENTATIVAS=0
:espera
timeout /t 2 /nobreak >nul
netsh wlan show interfaces | findstr /c:"%SSID%" >nul && goto conectado
set /a TENTATIVAS+=1
if %TENTATIVAS% lss 10 goto espera

echo.
echo Nao foi possivel conectar a %SSID%.
echo A rede %REDE_ANTIGA% foi mantida para voce nao ficar sem internet.
echo Verifique se esta no alcance da rede e tente novamente.
goto fim

:conectado
echo Conectado a %SSID%.
echo Removendo a rede antiga %REDE_ANTIGA%...
netsh wlan delete profile name="%REDE_ANTIGA%" >nul 2>&1
netsh wlan show profiles | findstr /c:"%REDE_ANTIGA%" >nul
if errorlevel 1 (
  echo Rede %REDE_ANTIGA% removida.
) else (
  echo Nao foi possivel remover %REDE_ANTIGA%. Execute este arquivo como administrador.
)

:fim
echo.
pause
endlocal
